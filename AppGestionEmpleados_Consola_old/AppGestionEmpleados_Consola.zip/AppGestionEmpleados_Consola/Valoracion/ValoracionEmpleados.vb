﻿Namespace AppEmpleados
    Module ValoracionEmpleados

        Sub Iniciar()
            Console.WriteLine(vbNewLine & " *** VALORACION DE EMPLEADOS ***" & vbNewLine)
        End Sub
    End Module
End Namespace
