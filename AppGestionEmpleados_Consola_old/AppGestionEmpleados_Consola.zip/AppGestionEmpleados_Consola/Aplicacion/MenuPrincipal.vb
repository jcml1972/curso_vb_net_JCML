﻿Namespace AppEmpleados
    Module MenuPrincipal
        Dim titulo As String = "MENU PRINCIPAL"
        Dim textosOpciones() As String = New String() {"Salir", "Gestion empleados", "Valoracion de empleados"}

        Sub Main()
            Dim codigoOpcion As Integer

            Do
                codigoOpcion = UtilidadesMenu.SeleccionarOpcion(titulo, textosOpciones)

                Select Case codigoOpcion
                    Case 1
                        Gestion.Menu.Iniciar()
                    Case 2
                        ValoracionEmpleados.Iniciar()
                End Select
            Loop Until codigoOpcion = 0
        End Sub

    End Module
End Namespace